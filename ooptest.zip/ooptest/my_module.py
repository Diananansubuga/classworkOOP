from question2 import addition

numbers=addition(3,4)
print("the sum of numbers is:  ",numbers)